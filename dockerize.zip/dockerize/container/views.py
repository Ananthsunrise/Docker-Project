from django.shortcuts import render
from django.http import HttpResponse  # Import HttpResponse

# Create your views here.
def welcome(request):
    return HttpResponse("Hello world")  # Corrected HttpResponse
